package main

func Feature001(arguments []string) int {
	totalRuneCount := 0
	for _, arg := range arguments {
		for range arg {
			totalRuneCount++
		}
	}
	return totalRuneCount
}
