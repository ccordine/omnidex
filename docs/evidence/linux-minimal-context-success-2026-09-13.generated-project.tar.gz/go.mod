module example.invalid/workload

go 1.24.0
