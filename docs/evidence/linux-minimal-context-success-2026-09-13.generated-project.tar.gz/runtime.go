package main

type TaskInput struct {
	Arguments     []string // Values the user supplies as command-line arguments, excluding the executable name.
	StandardInput string   // Text for behavior that explicitly consumes redirected or piped input.
}
