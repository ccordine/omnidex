package main

import "testing"

func MakeExampleInputFeature001() []string {
	return []string{"Hello, 世界", "こんにちは、世界", "Привет, мир!", "👋 Hello, 🌍!"}
}

func ExpectedFeature001(arguments []string) int {
	totalRuneCount := 0
	for _, text := range arguments {
		runeSlice := []rune(text)
		totalRuneCount += len(runeSlice)
	}
	return totalRuneCount
}

func TestFeature001(t *testing.T) {
	input001 := MakeExampleInputFeature001()
	value001 := Feature001(input001)
	expected := ExpectedFeature001(input001)
	if value001 != expected {
		t.Fatalf("behavior mismatch: observed %v; expected %v", value001, expected)
	}
}
