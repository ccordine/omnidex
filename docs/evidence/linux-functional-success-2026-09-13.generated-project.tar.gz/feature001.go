package main

import (
	"fmt"
	"unicode/utf8"
)

func Feature001(input TaskInput, dependencies CapabilityResults) TaskResult {
	text := ""
	if len(input.Arguments) > 0 {
		text = input.Arguments[0]
	}
	charCount := utf8.RuneCountInString(text)
	result := TaskResult{Output: fmt.Sprintf("Character count: %d", charCount), Error: "", ExitCode: 0, State: make(map[string]string)}
	result.State["char_count"] = fmt.Sprintf("%d", charCount)
	return result
}
