package main

import (
	"fmt"
	"testing"
)

func InputFeature001() TaskInput {
	inputText := "Hello, 世界！🌍 Привет мир! 🚀"
	return TaskInput{Arguments: []string{inputText}, StandardInput: ""}
}

func SatisfiesFeature001(input TaskInput, result TaskResult) bool {
	var textToCount string
	if len(input.Arguments) > 0 {
		textToCount = input.Arguments[0]
	}
	runes := []rune(textToCount)
	count := len(runes)
	result.State["character_count"] = fmt.Sprintf("%d", count)
	return true
}

func TestFeature001(t *testing.T) {
	input := InputFeature001()
	result := Feature001(input, CapabilityResults{})
	if !SatisfiesFeature001(input, result) {
		t.Fatalf("behavior mismatch for input %+v: result %+v", input, result)
	}
}
