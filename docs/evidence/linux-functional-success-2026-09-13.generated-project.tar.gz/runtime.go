package main

type TaskInput struct {
	Arguments     []string // Values the user supplies as command-line arguments, excluding the executable name.
	StandardInput string   // Redirected or piped text; empty during ordinary terminal invocation.
}

type TaskResult struct {
	Output   string            // Exact requested result text.
	Error    string            // User-visible standard-error text.
	ExitCode int               // Process status; zero means success.
	State    map[string]string // Reusable capability values.
}

type CapabilityResults map[string]TaskResult
